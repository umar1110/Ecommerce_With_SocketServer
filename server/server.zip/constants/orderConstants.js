exports.orderStatus = {
  PROCESSING: 0,
  SHIPPED: 1,
  DELIVERED: 2,
  CANCELLED: 3,
  RETURNED: 4,
};
