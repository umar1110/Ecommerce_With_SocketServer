exports.userRoles = {
  ADMIN: 0,
  USER: 1,
};
